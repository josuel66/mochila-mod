package com.mochilaoj;

import com.mochilaoj.item.MochilaOJItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MochilaOJMod implements ModInitializer {
    public static final String MOD_ID = "mochilaoj";
    public static final MochilaOJItem MOCHILA_OJ = new MochilaOJItem(new Item.Settings());

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "mochila_oj"), MOCHILA_OJ);
        
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(MOCHILA_OJ);
        });
        
        System.out.println("¡MochilaOJ cargada!");
    }
}

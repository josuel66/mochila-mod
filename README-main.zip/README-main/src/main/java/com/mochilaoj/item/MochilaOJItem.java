package com.mochilaoj.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import com.mochilaoj.screen.MochilaOJScreenHandler;

public class MochilaOJItem extends Item {
    public static final int INVENTORY_SIZE = 27;

    public MochilaOJItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        
        if (!world.isClient) {
            final SimpleInventory inv = new SimpleInventory(INVENTORY_SIZE);
            
            NamedScreenHandlerFactory factory = new SimpleNamedScreenHandlerFactory(
                (syncId, playerInv, p) -> new MochilaOJScreenHandler(syncId, playerInv, inv),
                Text.literal("Mochila OJ")
            );
            
            player.openHandledScreen(factory);
        }
        
        return TypedActionResult.success(stack);
    }
}
